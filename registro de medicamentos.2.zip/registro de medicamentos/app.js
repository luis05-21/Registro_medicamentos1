const express = require('express');
const { connectToDatabase, sql } = require('./db'); // Importamos la función de conexión

const app = express();
const port = 3000;

// Conectar a la base de datos
connectToDatabase();

// Ruta de ejemplo para obtener todos los productos
app.get('/productos', async (req, res) => {
    try {
        const result = await sql.query('SELECT * FROM Productos');
        res.json(result.recordset); // Devuelve los productos como respuesta JSON
    } catch (err) {
        res.status(500).send('Error al obtener los productos');
        console.error(err);
    }
});

// Escuchar en el puerto
app.listen(port, () => {
    console.log(`Servidor corriendo en http://localhost:${port}`);
});

 