<script>
const metodoPago = document.getElementById('metodo-pago');
const tarjetaInfo = document.getElementById('tarjeta-info');

metodoPago.addEventListener('change', function() {
    if (metodoPago.value === 'tarjeta') {
        tarjetaInfo.style.display = 'block';
    } else {
        tarjetaInfo.style.display = 'none';
    }
});
</script>