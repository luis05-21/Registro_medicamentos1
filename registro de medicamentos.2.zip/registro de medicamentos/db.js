const sql = require('mssql');

const config = {
    user: 'tu_usuario', // Reemplaza con tu usuario de SQL Server
    password: 'tu_contraseña', // Reemplaza con tu contraseña de SQL Server
    server: 'tu_servidor', // El nombre del servidor, puede ser "localhost" si es en tu máquina local
    database: 'nombre_base_datos', // El nombre de la base de datos que has creado
    options: {
        encrypt: true, // Usar en caso de tener cifrado en la conexión
        trustServerCertificate: true // Establece si quieres confiar en el certificado del servidor
    }
};

async function connectToDatabase() {
    try {
        await sql.connect(config);
        console.log('Conexión exitosa a la base de datos');
    } catch (err) {
        console.error('Error al conectar a la base de datos:', err);
    }
}

module.exports = { sql, connectToDatabase };
