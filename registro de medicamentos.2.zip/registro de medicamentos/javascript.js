app.post('/productos', async (req, res) => {
    const { nombre, precio, stock, descripcion } = req.body;
    try {
        const result = await sql.query(`
            INSERT INTO Productos (Nombre, Precio, Stock, Descripcion)
            VALUES ('${nombre}', ${precio}, ${stock}, '${descripcion}')
        `);
        res.status(201).send('Producto agregado correctamente');
    } catch (err) {
        res.status(500).send('Error al agregar el producto');
        console.error(err);
    }
});

app.get('/productos/:id', async (req, res) => {
    const { id } = req.params;
    try {
        const result = await sql.query(`SELECT * FROM Productos WHERE ProductoId = ${id}`);
        if (result.recordset.length > 0) {
            res.json(result.recordset[0]); 
        } else {
            res.status(404).send('Producto no encontrado');
        }
    } catch (err) {
        res.status(500).send('Error al obtener el producto');
        console.error(err);
    }
});

fetch('/productos')
    .then(response => response.json())
    .then(data => {
        console.log(data); 
    })
    .catch(error => console.error('Error al obtener productos:', error));
